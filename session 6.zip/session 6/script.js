const form = document.getElementById("regForm");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const phoneInput = document.getElementById("phone");
const successMessage = document.getElementById("success-message");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  let isValid = validateInputs();

  if (isValid) {
    successMessage.textContent = "Form submitted successfully!";
    successMessage.style.color = "green";
    form.reset();
  } else {
    successMessage.textContent = "";
  }
});

function validateInputs() {
  let valid = true;

  // Validate Name
  if (nameInput.value.trim() === "") {
    setError(nameInput, "Name cannot be empty");
    valid = false;
  } else {
    clearError(nameInput);
  }

  // Validate Email
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (emailInput.value.trim() === "") {
    setError(emailInput, "Email cannot be empty");
    valid = false;
  } else if (!emailPattern.test(emailInput.value)) {
    setError(emailInput, "Please enter a valid email");
    valid = false;
  } else {
    clearError(emailInput);
  }

  // Validate Phone
  if (phoneInput.value.trim() === "") {
    setError(phoneInput, "Phone number cannot be empty");
    valid = false;
  } else if (!/^[0-9]+$/.test(phoneInput.value)) {
    setError(phoneInput, "Phone number must be numeric");
    valid = false;
  } else {
    clearError(phoneInput);
  }

  return valid;
}

function setError(input, message) {
  const formGroup = input.parentElement;
  const errorMsg = formGroup.querySelector(".error-message");
  errorMsg.textContent = message;
  input.style.borderColor = "#d93025";
}

function clearError(input) {
  const formGroup = input.parentElement;
  const errorMsg = formGroup.querySelector(".error-message");
  errorMsg.textContent = "";
  input.style.borderColor = "#ccc";
}

// Real-time validation
[nameInput, emailInput, phoneInput].forEach(input => {
  input.addEventListener("input", validateInputs);
});
