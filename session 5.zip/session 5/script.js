const display = document.getElementById("display");
const errorMsg = document.getElementById("error-message");

function append(value) {
  display.value += value;
  errorMsg.textContent = "";
}

function clearDisplay() {
  display.value = "";
  errorMsg.textContent = "";
}

function deleteLast() {
  display.value = display.value.slice(0, -1);
}

function calculate() {
  try {
    let expression = display.value;

    // Prevent invalid input like multiple operators
    if (/[^0-9+\-*/.%]/.test(expression)) {
      throw new Error("Invalid input");
    }

    // Prevent division by zero
    if (expression.includes("/0")) {
      throw new Error("Cannot divide by zero");
    }

    let result = eval(expression);
    if (isNaN(result) || !isFinite(result)) {
      throw new Error("Invalid operation");
    }

    display.value = result;
    errorMsg.textContent = "";
  } catch (err) {
    errorMsg.textContent = err.message;
    display.value = "";
  }
}
